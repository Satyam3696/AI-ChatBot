package com.AI.chatbot.chatbot_back.controller;

import com.AI.chatbot.chatbot_back.model.*;
import com.AI.chatbot.chatbot_back.repository.*;
import com.AI.chatbot.chatbot_back.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "http://localhost:3000")
public class ChatController {

    @Autowired
    private OpenAIService openAIService;

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @PostMapping
    public ResponseEntity<Map<String, String>> chat(@RequestBody Map<String, String> request) {
        String userMessage = request.get("message");

        // Save user message
        chatMessageRepository.save(new ChatMessage("user", userMessage));

        // Get OpenAI response
        String botReply = openAIService.getChatbotResponse(userMessage);

        // Save bot reply
        chatMessageRepository.save(new ChatMessage("bot", botReply));

        // Send bot reply back to frontend
        Map<String, String> response = new HashMap<>();
        response.put("reply", botReply);
        return ResponseEntity.ok(response);
    }
}
