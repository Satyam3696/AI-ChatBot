package com.AI.chatbot.chatbot_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatbotBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatbotBackApplication.class, args);
	}

}
