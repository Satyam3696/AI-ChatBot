package com.AI.chatbot.chatbot_back.repository;

import com.AI.chatbot.chatbot_back.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
}
