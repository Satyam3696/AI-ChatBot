package com.AI.chatbot.chatbot_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbotBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
